"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { cn } from "@/lib/utils"

interface PixelTransitionProps {
  children: React.ReactNode
  className?: string
}

export function PixelTransition({ children, className }: PixelTransitionProps) {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
    return () => setIsVisible(false)
  }, [])

  return (
    <div
      className={cn(
        "transition-all duration-500",
        isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95",
        "pixel-appear",
        className,
      )}
    >
      {children}
    </div>
  )
}

export function PageTransition({ children, className }: PixelTransitionProps) {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    // Pequeno atraso para garantir que a animação seja visível
    const timer = setTimeout(() => {
      setIsVisible(true)
    }, 100)
    return () => {
      clearTimeout(timer)
      setIsVisible(false)
    }
  }, [])

  return (
    <div
      className={cn(
        "transition-all duration-700",
        isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8",
        "pixel-slide-up",
        className,
      )}
    >
      {children}
    </div>
  )
}

export function PixelButton({ children, className, onClick, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const [isPressed, setIsPressed] = useState(false)

  return (
    <button
      className={cn(
        "relative overflow-hidden border-b-4 border-r-4 border-black bg-[#EA1D2C] font-minecraft text-white transition-all",
        "hover:translate-y-1 hover:border-b-2 hover:border-r-2 hover:bg-[#c81623]",
        "active:translate-y-1 active:border-b-2 active:border-r-2",
        "before:absolute before:inset-0 before:bg-white before:opacity-0 hover:before:opacity-10 active:before:opacity-20",
        "pixel-press",
        isPressed ? "pixel-pressed" : "",
        className,
      )}
      onClick={(e) => {
        setIsPressed(true)
        setTimeout(() => setIsPressed(false), 300)
        onClick?.(e)
      }}
      {...props}
    >
      {children}
    </button>
  )
}

export function PixelCard({ children, className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <div
      className={cn(
        "border-4 border-black bg-[#C6C6C6] transition-all duration-300",
        "shadow-[8px_8px_0px_0px_rgba(0,0,0,0.5)]",
        "hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,0.5)] hover:translate-y-1",
        "pixel-hover",
        isHovered ? "pixel-hovered" : "",
        className,
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      {...props}
    >
      {children}
    </div>
  )
}

export function LinkWrapper({
  children,
  href,
  className,
}: { children: React.ReactNode; href: string; className?: string }) {
  const router = useRouter()
  const [isTransitioning, setIsTransitioning] = useState(false)

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault()
    setIsTransitioning(true)

    // Adiciona um pequeno atraso para a animação ser visível
    setTimeout(() => {
      router.push(href)
    }, 400)
  }

  return (
    <a href={href} onClick={handleClick} className={cn(isTransitioning ? "pixel-exit" : "", className)}>
      {children}
    </a>
  )
}
