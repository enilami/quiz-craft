"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { toast } from "@/components/ui/use-toast"
import { PageTransition, PixelButton, PixelTransition } from "@/components/pixel-transition"
import Link from "next/link"

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [userType, setUserType] = useState("user")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Simulação de login com verificação de credenciais para admin
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Verificação de credenciais para admin
      if (userType === "admin") {
        if (email === "alinebarbosa.alm@gmail.com" && password === "barbosa123") {
          router.push("/admin/dashboard")
          toast({
            title: "Login de administrador realizado com sucesso",
            description: "Bem-vindo ao painel administrativo!",
          })
        } else {
          toast({
            title: "Erro de autenticação",
            description: "Credenciais de administrador inválidas.",
            variant: "destructive",
          })
          setIsLoading(false)
          return
        }
      } else {
        // Login de usuário normal
        router.push("/quizzes")
        toast({
          title: "Login realizado com sucesso",
          description: `Bem-vindo, ${email}!`,
        })
      }
    } catch (error) {
      toast({
        title: "Erro ao fazer login",
        description: "Verifique suas credenciais e tente novamente.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[#333333] bg-[url('/placeholder.svg?height=600&width=600')] bg-repeat scanline">
      <PageTransition>
        <div className="mx-auto flex w-full max-w-md flex-col justify-center space-y-6">
          <PixelTransition className="flex flex-col space-y-2 text-center">
            <h1 className="font-minecraft text-4xl font-bold tracking-wide text-white drop-shadow-[2px_2px_0px_#000] text-appear">
              QuizCraft
            </h1>
            <p className="font-minecraft text-lg text-white drop-shadow-[1px_1px_0px_#000]">Entre para jogar!</p>
          </PixelTransition>

          <Card className="border-4 border-black bg-[#C6C6C6] shadow-[8px_8px_0px_0px_rgba(0,0,0,0.5)]">
            <form onSubmit={handleSubmit}>
              <CardHeader className="border-b-4 border-black bg-[#EA1D2C] pb-4">
                <CardTitle className="font-minecraft text-2xl text-white drop-shadow-[1px_1px_0px_#000]">
                  LOGIN
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 p-6">
                <PixelTransition>
                  <div className="space-y-2">
                    <Label htmlFor="email" className="font-minecraft text-black">
                      Email
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="seu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="border-2 border-black bg-white font-minecraft placeholder:text-gray-500"
                    />
                  </div>
                </PixelTransition>

                <PixelTransition>
                  <div className="space-y-2">
                    <Label htmlFor="password" className="font-minecraft text-black">
                      Senha
                    </Label>
                    <Input
                      id="password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="border-2 border-black bg-white font-minecraft placeholder:text-gray-500"
                    />
                  </div>
                </PixelTransition>

                <PixelTransition>
                  <div className="space-y-2">
                    <Label className="font-minecraft text-black">Tipo de Usuário</Label>
                    <RadioGroup
                      defaultValue="user"
                      value={userType}
                      onValueChange={setUserType}
                      className="flex space-x-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="user" id="user" className="border-2 border-black" />
                        <Label htmlFor="user" className="font-minecraft text-black">
                          Jogador
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="admin" id="admin" className="border-2 border-black" />
                        <Label htmlFor="admin" className="font-minecraft text-black">
                          Admin
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>
                </PixelTransition>
              </CardContent>
              <CardFooter className="flex flex-col border-t-4 border-black bg-[#C6C6C6] p-6">
                <PixelButton
                  className="w-full border-b-4 border-r-4 border-black bg-[#EA1D2C] font-minecraft text-white"
                  type="submit"
                  disabled={isLoading}
                >
                  {isLoading ? "Entrando..." : "ENTRAR"}
                </PixelButton>
                <p className="mt-4 text-center font-minecraft text-sm text-black">
                  Não tem uma conta?{" "}
                  <Link href="#" className="text-[#EA1D2C] underline underline-offset-4 hover:text-[#c81623]">
                    Registre-se
                  </Link>
                </p>
              </CardFooter>
            </form>
          </Card>
        </div>
      </PageTransition>
    </div>
  )
}
