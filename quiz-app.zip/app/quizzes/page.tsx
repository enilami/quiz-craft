"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { PageTransition, PixelButton, PixelCard, PixelTransition, LinkWrapper } from "@/components/pixel-transition"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { ShieldCheck } from "lucide-react"

// Dados simulados de quizzes
const quizzes = [
  {
    id: 1,
    title: "Conhecimentos Gerais",
    description: "Teste seus conhecimentos sobre diversos assuntos.",
    questions: 10,
    difficulty: "Médio",
    icon: "🧠",
  },
  {
    id: 2,
    title: "História do Brasil",
    description: "Perguntas sobre a história do nosso país.",
    questions: 15,
    difficulty: "Difícil",
    icon: "🇧🇷",
  },
  {
    id: 3,
    title: "Matemática Básica",
    description: "Operações e conceitos fundamentais de matemática.",
    questions: 8,
    difficulty: "Fácil",
    icon: "🔢",
  },
  {
    id: 4,
    title: "Geografia Mundial",
    description: "Países, capitais e características geográficas.",
    questions: 12,
    difficulty: "Médio",
    icon: "🌎",
  },
]

export default function QuizzesPage() {
  const [mounted, setMounted] = useState(false)
  const [firstName, setFirstName] = useState("")
  const [lastName, setLastName] = useState("")
  const [isRegistered, setIsRegistered] = useState(false)

  useEffect(() => {
    setMounted(true)
    // Verificar se o usuário já se registrou anteriormente
    const storedFirstName = localStorage.getItem("quizUserFirstName")
    const storedLastName = localStorage.getItem("quizUserLastName")

    if (storedFirstName && storedLastName) {
      setFirstName(storedFirstName)
      setLastName(storedLastName)
      setIsRegistered(true)
    }
  }, [])

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault()

    if (!firstName.trim() || !lastName.trim()) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha seu nome e sobrenome para continuar.",
        variant: "destructive",
      })
      return
    }

    // Salvar informações do usuário
    localStorage.setItem("quizUserFirstName", firstName)
    localStorage.setItem("quizUserLastName", lastName)
    setIsRegistered(true)

    toast({
      title: "Registro concluído!",
      description: `Bem-vindo(a), ${firstName} ${lastName}! Você já pode jogar os quizzes.`,
    })
  }

  if (!mounted) return null

  return (
    <div className="min-h-screen bg-[#333333] bg-[url('/placeholder.svg?height=600&width=600')] bg-repeat scanline">
      <header className="border-b-4 border-black bg-[#EA1D2C] p-4">
        <div className="container mx-auto flex items-center justify-between">
          <h1 className="font-minecraft text-3xl font-bold text-white drop-shadow-[2px_2px_0px_#000]">QuizCraft</h1>
          <div className="flex items-center space-x-4">
            {isRegistered ? (
              <>
                <div className="rounded-md border-2 border-black bg-[#333333] px-3 py-1 font-minecraft text-white">
                  {firstName} {lastName}
                </div>
                <PixelButton
                  className="border-b-4 border-r-4 border-black bg-[#333333] font-minecraft text-white"
                  onClick={() => {
                    localStorage.removeItem("quizUserFirstName")
                    localStorage.removeItem("quizUserLastName")
                    setIsRegistered(false)
                    setFirstName("")
                    setLastName("")
                  }}
                >
                  Sair
                </PixelButton>
              </>
            ) : (
              <LinkWrapper href="/login">
                <PixelButton className="border-b-4 border-r-4 border-black bg-[#333333] font-minecraft text-white">
                  <ShieldCheck className="mr-2 h-4 w-4" />
                  Acesso Admin
                </PixelButton>
              </LinkWrapper>
            )}
          </div>
        </div>
      </header>

      <div className="container mx-auto py-10">
        <PageTransition>
          {!isRegistered ? (
            <div className="mx-auto max-w-md">
              <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[8px_8px_0px_0px_rgba(0,0,0,0.5)]">
                <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                  <CardTitle className="font-minecraft text-xl text-white drop-shadow-[1px_1px_0px_#000]">
                    Registre-se para jogar
                  </CardTitle>
                  <CardDescription className="font-minecraft text-white opacity-90">
                    Informe seu nome e sobrenome para começar
                  </CardDescription>
                </CardHeader>
                <form onSubmit={handleRegister}>
                  <CardContent className="space-y-4 p-6">
                    <PixelTransition>
                      <div className="space-y-2">
                        <Label htmlFor="firstName" className="font-minecraft text-black">
                          Nome
                        </Label>
                        <Input
                          id="firstName"
                          value={firstName}
                          onChange={(e) => setFirstName(e.target.value)}
                          required
                          className="border-2 border-black bg-white font-minecraft"
                          placeholder="Digite seu nome"
                        />
                      </div>
                    </PixelTransition>

                    <PixelTransition>
                      <div className="space-y-2">
                        <Label htmlFor="lastName" className="font-minecraft text-black">
                          Sobrenome
                        </Label>
                        <Input
                          id="lastName"
                          value={lastName}
                          onChange={(e) => setLastName(e.target.value)}
                          required
                          className="border-2 border-black bg-white font-minecraft"
                          placeholder="Digite seu sobrenome"
                        />
                      </div>
                    </PixelTransition>
                  </CardContent>
                  <CardFooter className="border-t-4 border-black bg-[#C6C6C6] p-4">
                    <PixelButton
                      type="submit"
                      className="w-full border-b-4 border-r-4 border-black bg-[#EA1D2C] font-minecraft text-white"
                    >
                      CONTINUAR
                    </PixelButton>
                  </CardFooter>
                </form>
              </PixelCard>
            </div>
          ) : (
            <>
              <div className="mb-10 space-y-4">
                <h1 className="font-minecraft text-3xl font-bold text-white drop-shadow-[2px_2px_0px_#000] text-appear">
                  Quizzes Disponíveis
                </h1>
                <p className="font-minecraft text-lg text-white drop-shadow-[1px_1px_0px_#000]">
                  Olá, {firstName}! Escolha um quiz para começar sua aventura!
                </p>
              </div>

              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {quizzes.map((quiz, index) => (
                  <PixelTransition key={quiz.id} className={`delay-${index * 100}`}>
                    <PixelCard className="overflow-hidden">
                      <CardHeader className="border-b-4 border-black bg-[#EA1D2C] pb-3">
                        <div className="flex items-center gap-2">
                          <span className="text-3xl">{quiz.icon}</span>
                          <CardTitle className="font-minecraft text-xl text-white drop-shadow-[1px_1px_0px_#000]">
                            {quiz.title}
                          </CardTitle>
                        </div>
                        <CardDescription className="font-minecraft text-white opacity-90">
                          {quiz.description}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="p-4">
                        <div className="grid grid-cols-2 gap-2 font-minecraft text-sm">
                          <div className="flex flex-col rounded-md border-2 border-black bg-[#E7E7E7] p-2">
                            <span className="text-black opacity-75">Perguntas</span>
                            <span className="font-bold text-black">{quiz.questions}</span>
                          </div>
                          <div className="flex flex-col rounded-md border-2 border-black bg-[#E7E7E7] p-2">
                            <span className="text-black opacity-75">Dificuldade</span>
                            <span className="font-bold text-black">{quiz.difficulty}</span>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="border-t-4 border-black bg-[#C6C6C6] p-4">
                        <LinkWrapper href={`/quizzes/${quiz.id}`} className="w-full">
                          <PixelButton className="w-full">JOGAR QUIZ</PixelButton>
                        </LinkWrapper>
                      </CardFooter>
                    </PixelCard>
                  </PixelTransition>
                ))}
              </div>
            </>
          )}
        </PageTransition>
      </div>
    </div>
  )
}
