"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { PageTransition, PixelButton, PixelCard, PixelTransition, LinkWrapper } from "@/components/pixel-transition"
import { toast } from "@/components/ui/use-toast"

// Dados simulados de um quiz
const quizData = {
  id: 1,
  title: "Conhecimentos Gerais",
  description: "Teste seus conhecimentos sobre diversos assuntos.",
  questions: [
    {
      id: 1,
      question: "Qual é a capital do Brasil?",
      options: ["Rio de Janeiro", "São Paulo", "Brasília", "Salvador"],
      correctAnswer: "Brasília",
    },
    {
      id: 2,
      question: "Quem pintou a Mona Lisa?",
      options: ["Vincent van Gogh", "Leonardo da Vinci", "Pablo Picasso", "Michelangelo"],
      correctAnswer: "Leonardo da Vinci",
    },
    {
      id: 3,
      question: "Qual é o maior planeta do Sistema Solar?",
      options: ["Terra", "Marte", "Júpiter", "Saturno"],
      correctAnswer: "Júpiter",
    },
    {
      id: 4,
      question: "Qual é o menor país do mundo?",
      options: ["Mônaco", "Vaticano", "Nauru", "San Marino"],
      correctAnswer: "Vaticano",
    },
    {
      id: 5,
      question: "Qual é o elemento químico mais abundante na crosta terrestre?",
      options: ["Ferro", "Silício", "Oxigênio", "Alumínio"],
      correctAnswer: "Oxigênio",
    },
  ],
}

export default function QuizPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedOption, setSelectedOption] = useState<string | null>(null)
  const [score, setScore] = useState(0)
  const [showResults, setShowResults] = useState(false)
  const [answers, setAnswers] = useState<string[]>(Array(quizData.questions.length).fill(""))
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [userName, setUserName] = useState("")

  useEffect(() => {
    setMounted(true)

    // Verificar se o usuário está registrado
    const firstName = localStorage.getItem("quizUserFirstName")
    const lastName = localStorage.getItem("quizUserLastName")

    if (firstName && lastName) {
      setUserName(`${firstName} ${lastName}`)
    } else {
      // Redirecionar para a página de quizzes se o usuário não estiver registrado
      toast({
        title: "Registro necessário",
        description: "Por favor, informe seu nome e sobrenome para jogar.",
        variant: "destructive",
      })
      router.push("/quizzes")
    }
  }, [router])

  const handleOptionSelect = (option: string) => {
    setSelectedOption(option)
    const newAnswers = [...answers]
    newAnswers[currentQuestion] = option
    setAnswers(newAnswers)
  }

  const handleNext = () => {
    if (selectedOption === quizData.questions[currentQuestion].correctAnswer) {
      setScore(score + 1)
    }

    setIsTransitioning(true)

    setTimeout(() => {
      if (currentQuestion < quizData.questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1)
        setSelectedOption(answers[currentQuestion + 1] || null)
      } else {
        setShowResults(true)
      }
      setIsTransitioning(false)
    }, 500)
  }

  const handlePrevious = () => {
    setIsTransitioning(true)

    setTimeout(() => {
      if (currentQuestion > 0) {
        setCurrentQuestion(currentQuestion - 1)
        setSelectedOption(answers[currentQuestion - 1] || null)
      }
      setIsTransitioning(false)
    }, 500)
  }

  const handleRestart = () => {
    setIsTransitioning(true)

    setTimeout(() => {
      setCurrentQuestion(0)
      setSelectedOption(null)
      setScore(0)
      setShowResults(false)
      setAnswers(Array(quizData.questions.length).fill(""))
      setIsTransitioning(false)
    }, 500)
  }

  const progress = ((currentQuestion + 1) / quizData.questions.length) * 100

  if (!mounted) return null

  if (showResults) {
    return (
      <div className="min-h-screen bg-[#333333] bg-[url('/placeholder.svg?height=600&width=600')] bg-repeat scanline flex flex-col items-center justify-center py-10">
        <PageTransition>
          <PixelCard className="w-full max-w-2xl">
            <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
              <CardTitle className="font-minecraft text-white">Resultados do Quiz</CardTitle>
              <CardDescription className="font-minecraft text-white opacity-90">
                {userName}, você completou o quiz "{quizData.title}"
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 p-6">
              <PixelTransition>
                <div className="text-center">
                  <p className="text-4xl font-minecraft font-bold pixel-glow">
                    {score} / {quizData.questions.length}
                  </p>
                  <p className="font-minecraft text-muted-foreground">
                    Você acertou {score} de {quizData.questions.length} perguntas
                  </p>
                </div>
              </PixelTransition>
              <PixelTransition className="delay-200">
                <Progress value={(score / quizData.questions.length) * 100} className="h-3" />
              </PixelTransition>
            </CardContent>
            <CardFooter className="flex justify-between border-t-4 border-black bg-[#C6C6C6] p-4">
              <LinkWrapper href="/quizzes">
                <PixelButton className="border-b-4 border-r-4 border-black bg-[#333333] font-minecraft text-white">
                  Voltar para Quizzes
                </PixelButton>
              </LinkWrapper>
              <PixelButton onClick={handleRestart}>Tentar Novamente</PixelButton>
            </CardFooter>
          </PixelCard>
        </PageTransition>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#333333] bg-[url('/placeholder.svg?height=600&width=600')] bg-repeat scanline flex flex-col items-center justify-center py-10">
      <PageTransition>
        <PixelCard className="w-full max-w-2xl">
          <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="font-minecraft text-white">{quizData.title}</CardTitle>
                <CardDescription className="font-minecraft text-white opacity-90">
                  Pergunta {currentQuestion + 1} de {quizData.questions.length}
                </CardDescription>
              </div>
              <div className="flex flex-col items-end">
                <div className="font-minecraft text-sm font-medium text-white">Pontuação: {score}</div>
                <div className="font-minecraft text-xs text-white opacity-80">Jogador: {userName}</div>
              </div>
            </div>
            <Progress value={progress} className="h-2 mt-2" />
          </CardHeader>
          <CardContent className={`space-y-4 p-6 ${isTransitioning ? "pixel-exit" : "pixel-appear"}`}>
            <PixelTransition>
              <div className="text-xl font-minecraft font-medium">{quizData.questions[currentQuestion].question}</div>
            </PixelTransition>
            <RadioGroup value={selectedOption || ""} onValueChange={handleOptionSelect} className="space-y-2">
              {quizData.questions[currentQuestion].options.map((option, index) => (
                <PixelTransition key={option} className={`delay-${index * 100}`}>
                  <div className="flex items-center space-x-2 rounded-md border-2 border-black bg-[#E7E7E7] p-3 hover:bg-[#D0D0D0] transition-all">
                    <RadioGroupItem value={option} id={option} className="border-2 border-black" />
                    <Label htmlFor={option} className="flex-1 cursor-pointer font-minecraft">
                      {option}
                    </Label>
                  </div>
                </PixelTransition>
              ))}
            </RadioGroup>
          </CardContent>
          <CardFooter className="flex justify-between border-t-4 border-black bg-[#C6C6C6] p-4">
            <PixelButton
              onClick={handlePrevious}
              disabled={currentQuestion === 0}
              className="border-b-4 border-r-4 border-black bg-[#333333] font-minecraft text-white disabled:opacity-50"
            >
              Anterior
            </PixelButton>
            <PixelButton onClick={handleNext} disabled={!selectedOption}>
              {currentQuestion === quizData.questions.length - 1 ? "Finalizar" : "Próxima"}
            </PixelButton>
          </CardFooter>
        </PixelCard>
      </PageTransition>
    </div>
  )
}
