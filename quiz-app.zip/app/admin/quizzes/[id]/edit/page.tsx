"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { PageTransition, PixelButton, PixelCard, PixelTransition, LinkWrapper } from "@/components/pixel-transition"
import { ArrowLeft, Save } from "lucide-react"

// Dados simulados do quiz
const quizData = {
  id: 1,
  title: "Conhecimentos Gerais",
  description: "Teste seus conhecimentos sobre diversos assuntos.",
  timeLimit: 60,
  difficulty: "Médio",
  category: "Geral",
}

export default function EditQuizPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [quiz, setQuiz] = useState(quizData)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setQuiz({ ...quiz, [name]: name === "timeLimit" ? Number.parseInt(value) || 0 : value })
  }

  const handleSave = () => {
    // Aqui você implementaria a lógica para salvar as alterações no backend
    alert("Quiz atualizado com sucesso!")
    router.push("/admin/dashboard")
  }

  if (!mounted) return null

  return (
    <div className="min-h-screen bg-[#333333] bg-[url('/placeholder.svg?height=600&width=600')] bg-repeat scanline">
      <div className="border-b-4 border-black bg-[#EA1D2C]">
        <div className="container mx-auto flex h-16 items-center px-4">
          <div className="flex items-center space-x-4">
            <LinkWrapper href="/admin/dashboard">
              <PixelButton className="border-2 border-black bg-[#333333] font-minecraft text-white">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Voltar
              </PixelButton>
            </LinkWrapper>
            <span className="font-minecraft text-2xl font-bold text-white drop-shadow-[2px_2px_0px_#000]">
              Editar Quiz
            </span>
          </div>
        </div>
      </div>

      <div className="container mx-auto py-8">
        <PageTransition>
          <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
            <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
              <CardTitle className="font-minecraft text-white">Editar Quiz #{quiz.id}</CardTitle>
              <CardDescription className="font-minecraft text-white opacity-90">
                Atualize as informações do quiz
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              <PixelTransition>
                <div className="space-y-2">
                  <Label htmlFor="title" className="font-minecraft">
                    Título
                  </Label>
                  <Input
                    id="title"
                    name="title"
                    value={quiz.title}
                    onChange={handleChange}
                    className="border-2 border-black bg-white font-minecraft"
                  />
                </div>
              </PixelTransition>

              <PixelTransition className="delay-100">
                <div className="space-y-2">
                  <Label htmlFor="description" className="font-minecraft">
                    Descrição
                  </Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={quiz.description}
                    onChange={handleChange}
                    className="border-2 border-black bg-white font-minecraft"
                    rows={3}
                  />
                </div>
              </PixelTransition>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <PixelTransition className="delay-200">
                  <div className="space-y-2">
                    <Label htmlFor="timeLimit" className="font-minecraft">
                      Tempo Limite (segundos)
                    </Label>
                    <Input
                      id="timeLimit"
                      name="timeLimit"
                      type="number"
                      value={quiz.timeLimit}
                      onChange={handleChange}
                      className="border-2 border-black bg-white font-minecraft"
                      min={10}
                      max={300}
                    />
                  </div>
                </PixelTransition>

                <PixelTransition className="delay-300">
                  <div className="space-y-2">
                    <Label htmlFor="difficulty" className="font-minecraft">
                      Dificuldade
                    </Label>
                    <Input
                      id="difficulty"
                      name="difficulty"
                      value={quiz.difficulty}
                      onChange={handleChange}
                      className="border-2 border-black bg-white font-minecraft"
                    />
                  </div>
                </PixelTransition>

                <PixelTransition className="delay-400">
                  <div className="space-y-2">
                    <Label htmlFor="category" className="font-minecraft">
                      Categoria
                    </Label>
                    <Input
                      id="category"
                      name="category"
                      value={quiz.category}
                      onChange={handleChange}
                      className="border-2 border-black bg-white font-minecraft"
                    />
                  </div>
                </PixelTransition>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between border-t-4 border-black bg-[#C6C6C6] p-4">
              <LinkWrapper href="/admin/dashboard">
                <PixelButton className="border-b-4 border-r-4 border-black bg-[#333333] font-minecraft text-white">
                  Cancelar
                </PixelButton>
              </LinkWrapper>
              <div className="flex space-x-4">
                <LinkWrapper href={`/admin/quizzes/${quiz.id}/questions`}>
                  <PixelButton className="border-b-4 border-r-4 border-black bg-[#333333] font-minecraft text-white">
                    Gerenciar Perguntas
                  </PixelButton>
                </LinkWrapper>
                <PixelButton
                  onClick={handleSave}
                  className="border-b-4 border-r-4 border-black bg-[#EA1D2C] font-minecraft text-white"
                >
                  <Save className="mr-2 h-4 w-4" />
                  Salvar Alterações
                </PixelButton>
              </div>
            </CardFooter>
          </PixelCard>
        </PageTransition>
      </div>
    </div>
  )
}
