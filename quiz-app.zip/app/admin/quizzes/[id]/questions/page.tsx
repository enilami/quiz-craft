"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { PageTransition, PixelButton, PixelCard, PixelTransition, LinkWrapper } from "@/components/pixel-transition"
import { ArrowLeft, Plus, Save, Trash2, Edit, Check, X } from "lucide-react"

// Dados simulados de perguntas
const quizQuestions = [
  {
    id: 1,
    question: "Qual é a capital do Brasil?",
    options: ["Rio de Janeiro", "São Paulo", "Brasília", "Salvador"],
    correctAnswer: "Brasília",
  },
  {
    id: 2,
    question: "Quem pintou a Mona Lisa?",
    options: ["Vincent van Gogh", "Leonardo da Vinci", "Pablo Picasso", "Michelangelo"],
    correctAnswer: "Leonardo da Vinci",
  },
  {
    id: 3,
    question: "Qual é o maior planeta do Sistema Solar?",
    options: ["Terra", "Marte", "Júpiter", "Saturno"],
    correctAnswer: "Júpiter",
  },
  {
    id: 4,
    question: "Qual é o menor país do mundo?",
    options: ["Mônaco", "Vaticano", "Nauru", "San Marino"],
    correctAnswer: "Vaticano",
  },
  {
    id: 5,
    question: "Qual é o elemento químico mais abundante na crosta terrestre?",
    options: ["Ferro", "Silício", "Oxigênio", "Alumínio"],
    correctAnswer: "Oxigênio",
  },
]

// Dados simulados do quiz
const quizData = {
  id: 1,
  title: "Conhecimentos Gerais",
  description: "Teste seus conhecimentos sobre diversos assuntos.",
  timeLimit: 60,
}

export default function QuestionsPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [questions, setQuestions] = useState(quizQuestions)
  const [editingQuestion, setEditingQuestion] = useState<number | null>(null)
  const [newQuestion, setNewQuestion] = useState({
    question: "",
    options: ["", "", "", ""],
    correctAnswer: "",
  })
  const [isAddingNew, setIsAddingNew] = useState(false)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleEditQuestion = (id: number) => {
    setEditingQuestion(id)
    const questionToEdit = questions.find((q) => q.id === id)
    if (questionToEdit) {
      setNewQuestion({
        question: questionToEdit.question,
        options: [...questionToEdit.options],
        correctAnswer: questionToEdit.correctAnswer,
      })
    }
  }

  const handleSaveQuestion = (id: number) => {
    if (newQuestion.question.trim() === "" || newQuestion.options.some((opt) => opt.trim() === "")) {
      alert("Preencha todos os campos da pergunta e opções!")
      return
    }

    if (!newQuestion.options.includes(newQuestion.correctAnswer)) {
      alert("A resposta correta deve ser uma das opções!")
      return
    }

    setQuestions(
      questions.map((q) =>
        q.id === id
          ? {
              ...q,
              question: newQuestion.question,
              options: newQuestion.options,
              correctAnswer: newQuestion.correctAnswer,
            }
          : q,
      ),
    )
    setEditingQuestion(null)
    setNewQuestion({
      question: "",
      options: ["", "", "", ""],
      correctAnswer: "",
    })
  }

  const handleDeleteQuestion = (id: number) => {
    if (confirm("Tem certeza que deseja excluir esta pergunta?")) {
      setQuestions(questions.filter((q) => q.id !== id))
    }
  }

  const handleAddQuestion = () => {
    if (newQuestion.question.trim() === "" || newQuestion.options.some((opt) => opt.trim() === "")) {
      alert("Preencha todos os campos da pergunta e opções!")
      return
    }

    if (!newQuestion.options.includes(newQuestion.correctAnswer)) {
      alert("A resposta correta deve ser uma das opções!")
      return
    }

    const newId = Math.max(...questions.map((q) => q.id), 0) + 1
    setQuestions([
      ...questions,
      {
        id: newId,
        question: newQuestion.question,
        options: newQuestion.options,
        correctAnswer: newQuestion.correctAnswer,
      },
    ])
    setIsAddingNew(false)
    setNewQuestion({
      question: "",
      options: ["", "", "", ""],
      correctAnswer: "",
    })
  }

  const handleOptionChange = (index: number, value: string) => {
    const newOptions = [...newQuestion.options]
    newOptions[index] = value
    setNewQuestion({ ...newQuestion, options: newOptions })
  }

  if (!mounted) return null

  return (
    <div className="min-h-screen bg-[#333333] bg-[url('/placeholder.svg?height=600&width=600')] bg-repeat scanline">
      <div className="border-b-4 border-black bg-[#EA1D2C]">
        <div className="container mx-auto flex h-16 items-center px-4">
          <div className="flex items-center space-x-4">
            <LinkWrapper href="/admin/dashboard">
              <PixelButton className="border-2 border-black bg-[#333333] font-minecraft text-white">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Voltar
              </PixelButton>
            </LinkWrapper>
            <span className="font-minecraft text-2xl font-bold text-white drop-shadow-[2px_2px_0px_#000]">
              Gerenciar Perguntas
            </span>
          </div>
        </div>
      </div>

      <div className="container mx-auto py-8">
        <PageTransition>
          <PixelCard className="mb-8 border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
            <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
              <CardTitle className="font-minecraft text-white">{quizData.title}</CardTitle>
              <CardDescription className="font-minecraft text-white opacity-90">{quizData.description}</CardDescription>
            </CardHeader>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="font-minecraft">
                  <p>Total de perguntas: {questions.length}</p>
                  <p>Tempo limite: {quizData.timeLimit} segundos</p>
                </div>
                <PixelButton
                  onClick={() => {
                    setIsAddingNew(true)
                    setEditingQuestion(null)
                  }}
                  className="border-b-4 border-r-4 border-black bg-[#EA1D2C] font-minecraft text-white"
                  disabled={isAddingNew}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Nova Pergunta
                </PixelButton>
              </div>
            </CardContent>
          </PixelCard>

          {isAddingNew && (
            <PixelTransition>
              <PixelCard className="mb-8 border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                  <CardTitle className="font-minecraft text-white">Nova Pergunta</CardTitle>
                </CardHeader>
                <CardContent className="p-4 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="question" className="font-minecraft">
                      Pergunta
                    </Label>
                    <Textarea
                      id="question"
                      value={newQuestion.question}
                      onChange={(e) => setNewQuestion({ ...newQuestion, question: e.target.value })}
                      className="border-2 border-black bg-white font-minecraft"
                      placeholder="Digite a pergunta aqui..."
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="font-minecraft">Opções</Label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {newQuestion.options.map((option, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <Input
                            value={option}
                            onChange={(e) => handleOptionChange(index, e.target.value)}
                            className="border-2 border-black bg-white font-minecraft"
                            placeholder={`Opção ${index + 1}`}
                          />
                          <PixelButton
                            type="button"
                            onClick={() => setNewQuestion({ ...newQuestion, correctAnswer: option })}
                            className={`border-2 border-black ${
                              newQuestion.correctAnswer === option
                                ? "bg-[#EA1D2C] text-white"
                                : "bg-[#C6C6C6] text-black"
                            } font-minecraft`}
                          >
                            <Check className="h-4 w-4" />
                          </PixelButton>
                        </div>
                      ))}
                    </div>
                    <p className="text-sm font-minecraft text-muted-foreground">
                      Clique no botão ao lado da opção para marcá-la como correta.
                    </p>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between border-t-4 border-black bg-[#C6C6C6] p-4">
                  <PixelButton
                    onClick={() => setIsAddingNew(false)}
                    className="border-b-4 border-r-4 border-black bg-[#333333] font-minecraft text-white"
                  >
                    <X className="mr-2 h-4 w-4" />
                    Cancelar
                  </PixelButton>
                  <PixelButton
                    onClick={handleAddQuestion}
                    className="border-b-4 border-r-4 border-black bg-[#EA1D2C] font-minecraft text-white"
                  >
                    <Save className="mr-2 h-4 w-4" />
                    Salvar Pergunta
                  </PixelButton>
                </CardFooter>
              </PixelCard>
            </PixelTransition>
          )}

          <div className="space-y-4">
            {questions.map((question, index) => (
              <PixelTransition key={question.id} className={`delay-${index * 100}`}>
                <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                  {editingQuestion === question.id ? (
                    <>
                      <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                        <CardTitle className="font-minecraft text-white">Editar Pergunta #{question.id}</CardTitle>
                      </CardHeader>
                      <CardContent className="p-4 space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor={`question-${question.id}`} className="font-minecraft">
                            Pergunta
                          </Label>
                          <Textarea
                            id={`question-${question.id}`}
                            value={newQuestion.question}
                            onChange={(e) => setNewQuestion({ ...newQuestion, question: e.target.value })}
                            className="border-2 border-black bg-white font-minecraft"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label className="font-minecraft">Opções</Label>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {newQuestion.options.map((option, optIndex) => (
                              <div key={optIndex} className="flex items-center space-x-2">
                                <Input
                                  value={option}
                                  onChange={(e) => handleOptionChange(optIndex, e.target.value)}
                                  className="border-2 border-black bg-white font-minecraft"
                                  placeholder={`Opção ${optIndex + 1}`}
                                />
                                <PixelButton
                                  type="button"
                                  onClick={() => setNewQuestion({ ...newQuestion, correctAnswer: option })}
                                  className={`border-2 border-black ${
                                    newQuestion.correctAnswer === option
                                      ? "bg-[#EA1D2C] text-white"
                                      : "bg-[#C6C6C6] text-black"
                                  } font-minecraft`}
                                >
                                  <Check className="h-4 w-4" />
                                </PixelButton>
                              </div>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between border-t-4 border-black bg-[#C6C6C6] p-4">
                        <PixelButton
                          onClick={() => setEditingQuestion(null)}
                          className="border-b-4 border-r-4 border-black bg-[#333333] font-minecraft text-white"
                        >
                          <X className="mr-2 h-4 w-4" />
                          Cancelar
                        </PixelButton>
                        <PixelButton
                          onClick={() => handleSaveQuestion(question.id)}
                          className="border-b-4 border-r-4 border-black bg-[#EA1D2C] font-minecraft text-white"
                        >
                          <Save className="mr-2 h-4 w-4" />
                          Salvar Alterações
                        </PixelButton>
                      </CardFooter>
                    </>
                  ) : (
                    <>
                      <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                        <div className="flex items-center justify-between">
                          <CardTitle className="font-minecraft text-white">Pergunta #{question.id}</CardTitle>
                          <div className="flex space-x-2">
                            <PixelButton
                              onClick={() => handleEditQuestion(question.id)}
                              className="border-2 border-black bg-[#333333] font-minecraft text-white"
                              size="sm"
                            >
                              <Edit className="h-4 w-4" />
                            </PixelButton>
                            <PixelButton
                              onClick={() => handleDeleteQuestion(question.id)}
                              className="border-2 border-black bg-[#EA1D2C] font-minecraft text-white"
                              size="sm"
                            >
                              <Trash2 className="h-4 w-4" />
                            </PixelButton>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="p-4 space-y-4">
                        <div className="font-minecraft text-lg">{question.question}</div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {question.options.map((option, optIndex) => (
                            <div
                              key={optIndex}
                              className={`rounded-md border-2 border-black p-3 font-minecraft ${
                                option === question.correctAnswer
                                  ? "bg-[#EA1D2C] text-white"
                                  : "bg-[#E7E7E7] text-black"
                              }`}
                            >
                              {option === question.correctAnswer && <Check className="mr-2 h-4 w-4 inline-block" />}
                              {option}
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </>
                  )}
                </PixelCard>
              </PixelTransition>
            ))}
          </div>
        </PageTransition>
      </div>
    </div>
  )
}
