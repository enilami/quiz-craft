"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { PageTransition, PixelButton, PixelCard, PixelTransition, LinkWrapper } from "@/components/pixel-transition"
import { ArrowLeft, BarChart3, LineChart, PieChart, Users, Clock, Trophy } from "lucide-react"

// Dados simulados para estatísticas
const userStats = {
  totalUsers: 256,
  activeUsers: 178,
  newUsersThisMonth: 42,
  completionRate: 68,
  averageScore: 7.4,
  averageTimePerQuestion: 22,
  totalQuizzesCompleted: 1245,
}

const monthlyData = [
  { month: "Jan", users: 120, quizzes: 350, avgScore: 6.8 },
  { month: "Fev", users: 135, quizzes: 410, avgScore: 7.0 },
  { month: "Mar", users: 150, quizzes: 480, avgScore: 7.2 },
  { month: "Abr", users: 165, quizzes: 520, avgScore: 7.3 },
  { month: "Mai", users: 190, quizzes: 580, avgScore: 7.4 },
  { month: "Jun", users: 210, quizzes: 650, avgScore: 7.5 },
]

const quizPerformance = [
  { name: "Conhecimentos Gerais", participants: 145, avgScore: 7.2, completionRate: 82 },
  { name: "História do Brasil", participants: 89, avgScore: 6.5, completionRate: 75 },
  { name: "Matemática Básica", participants: 120, avgScore: 8.1, completionRate: 68 },
  { name: "Geografia Mundial", participants: 75, avgScore: 7.8, completionRate: 79 },
]

const topPerformers = [
  { name: "Carlos Oliveira", score: 950, quizzes: 15, avgTime: 18 },
  { name: "Mariana Silva", score: 820, quizzes: 12, avgTime: 20 },
  { name: "Rafael Souza", score: 780, quizzes: 14, avgTime: 19 },
  { name: "Juliana Costa", score: 750, quizzes: 10, avgTime: 21 },
  { name: "Fernando Lima", score: 720, quizzes: 11, avgTime: 23 },
]

const difficultyDistribution = [
  { difficulty: "Fácil", percentage: 35, color: "#4CAF50" },
  { difficulty: "Médio", percentage: 45, color: "#FFC107" },
  { difficulty: "Difícil", percentage: 20, color: "#F44336" },
]

const timeDistribution = [
  { range: "0-15s", percentage: 20, color: "#2196F3" },
  { range: "16-30s", percentage: 45, color: "#4CAF50" },
  { range: "31-45s", percentage: 25, color: "#FFC107" },
  { range: "46-60s", percentage: 10, color: "#F44336" },
]

export default function StatisticsPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("overview")
  const [selectedPeriod, setSelectedPeriod] = useState("month")
  const [selectedQuiz, setSelectedQuiz] = useState("all")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  // Função para calcular a altura máxima do gráfico de barras
  const getMaxValue = (data: any[], key: string) => {
    return Math.max(...data.map((item) => item[key])) * 1.2
  }

  // Função para calcular a altura da barra
  const calculateBarHeight = (value: number, maxValue: number, maxHeight = 150) => {
    return (value / maxValue) * maxHeight
  }

  if (!mounted) return null

  return (
    <div className="min-h-screen bg-[#333333] bg-[url('/placeholder.svg?height=600&width=600')] bg-repeat scanline">
      <div className="border-b-4 border-black bg-[#EA1D2C]">
        <div className="container mx-auto flex h-16 items-center px-4">
          <div className="flex items-center space-x-4">
            <LinkWrapper href="/admin/dashboard">
              <PixelButton className="border-2 border-black bg-[#333333] font-minecraft text-white">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Voltar
              </PixelButton>
            </LinkWrapper>
            <span className="font-minecraft text-2xl font-bold text-white drop-shadow-[2px_2px_0px_#000]">
              Estatísticas
            </span>
          </div>
          <div className="ml-auto flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Label className="font-minecraft text-white">Período:</Label>
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger className="w-[180px] border-2 border-black bg-[#C6C6C6] font-minecraft">
                  <SelectValue placeholder="Selecione o período" />
                </SelectTrigger>
                <SelectContent className="border-2 border-black bg-[#C6C6C6] font-minecraft">
                  <SelectItem value="week">Última Semana</SelectItem>
                  <SelectItem value="month">Último Mês</SelectItem>
                  <SelectItem value="quarter">Último Trimestre</SelectItem>
                  <SelectItem value="year">Último Ano</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <Label className="font-minecraft text-white">Quiz:</Label>
              <Select value={selectedQuiz} onValueChange={setSelectedQuiz}>
                <SelectTrigger className="w-[180px] border-2 border-black bg-[#C6C6C6] font-minecraft">
                  <SelectValue placeholder="Selecione o quiz" />
                </SelectTrigger>
                <SelectContent className="border-2 border-black bg-[#C6C6C6] font-minecraft">
                  <SelectItem value="all">Todos os Quizzes</SelectItem>
                  {quizPerformance.map((quiz) => (
                    <SelectItem key={quiz.name} value={quiz.name}>
                      {quiz.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto py-8">
        <PageTransition>
          <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList className="border-2 border-black bg-[#C6C6C6] p-1">
              <TabsTrigger
                value="overview"
                className="font-minecraft data-[state=active]:border-b-4 data-[state=active]:border-r-4 data-[state=active]:border-black data-[state=active]:bg-[#EA1D2C] data-[state=active]:text-white"
              >
                Visão Geral
              </TabsTrigger>
              <TabsTrigger
                value="performance"
                className="font-minecraft data-[state=active]:border-b-4 data-[state=active]:border-r-4 data-[state=active]:border-black data-[state=active]:bg-[#EA1D2C] data-[state=active]:text-white"
              >
                Desempenho
              </TabsTrigger>
              <TabsTrigger
                value="time"
                className="font-minecraft data-[state=active]:border-b-4 data-[state=active]:border-r-4 data-[state=active]:border-black data-[state=active]:bg-[#EA1D2C] data-[state=active]:text-white"
              >
                Tempo
              </TabsTrigger>
              <TabsTrigger
                value="trends"
                className="font-minecraft data-[state=active]:border-b-4 data-[state=active]:border-r-4 data-[state=active]:border-black data-[state=active]:bg-[#EA1D2C] data-[state=active]:text-white"
              >
                Tendências
              </TabsTrigger>
            </TabsList>

            {/* Visão Geral */}
            <TabsContent value="overview" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <PixelTransition>
                  <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C] pb-2">
                      <div className="flex flex-row items-center justify-between space-y-0">
                        <CardTitle className="font-minecraft text-sm text-white">Total de Usuários</CardTitle>
                        <Users className="h-4 w-4 text-white" />
                      </div>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <div className="font-minecraft text-2xl font-bold">{userStats.totalUsers}</div>
                      <p className="font-minecraft text-xs text-muted-foreground">
                        +{userStats.newUsersThisMonth} este mês
                      </p>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>

                <PixelTransition className="delay-100">
                  <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C] pb-2">
                      <div className="flex flex-row items-center justify-between space-y-0">
                        <CardTitle className="font-minecraft text-sm text-white">Quizzes Completados</CardTitle>
                        <Trophy className="h-4 w-4 text-white" />
                      </div>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <div className="font-minecraft text-2xl font-bold">{userStats.totalQuizzesCompleted}</div>
                      <p className="font-minecraft text-xs text-muted-foreground">
                        Taxa de conclusão: {userStats.completionRate}%
                      </p>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>

                <PixelTransition className="delay-200">
                  <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C] pb-2">
                      <div className="flex flex-row items-center justify-between space-y-0">
                        <CardTitle className="font-minecraft text-sm text-white">Pontuação Média</CardTitle>
                        <BarChart3 className="h-4 w-4 text-white" />
                      </div>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <div className="font-minecraft text-2xl font-bold">{userStats.averageScore.toFixed(1)}</div>
                      <p className="font-minecraft text-xs text-muted-foreground">de 10 pontos possíveis</p>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>

                <PixelTransition className="delay-300">
                  <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C] pb-2">
                      <div className="flex flex-row items-center justify-between space-y-0">
                        <CardTitle className="font-minecraft text-sm text-white">Tempo Médio</CardTitle>
                        <Clock className="h-4 w-4 text-white" />
                      </div>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <div className="font-minecraft text-2xl font-bold">{userStats.averageTimePerQuestion}s</div>
                      <p className="font-minecraft text-xs text-muted-foreground">por pergunta</p>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <PixelTransition>
                  <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                      <div className="flex items-center justify-between">
                        <CardTitle className="font-minecraft text-white">Distribuição por Dificuldade</CardTitle>
                        <PieChart className="h-5 w-5 text-white" />
                      </div>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="flex h-[200px] items-center justify-center">
                        <div className="relative h-[180px] w-[180px] rounded-full border-4 border-black bg-[#333333]">
                          {difficultyDistribution.map((item, index) => {
                            const previousPercentages = difficultyDistribution
                              .slice(0, index)
                              .reduce((sum, curr) => sum + curr.percentage, 0)

                            return (
                              <div
                                key={item.difficulty}
                                className="absolute left-1/2 top-1/2 origin-center -translate-x-1/2 -translate-y-1/2"
                                style={{
                                  width: "180px",
                                  height: "180px",
                                  clipPath: `polygon(0 0, 50% 50%, ${50 + 50 * Math.cos((previousPercentages / 100) * Math.PI * 2)}% ${50 + 50 * Math.sin((previousPercentages / 100) * Math.PI * 2)}%, ${50 + 50 * Math.cos(((previousPercentages + item.percentage) / 100) * Math.PI * 2)}% ${50 + 50 * Math.sin(((previousPercentages + item.percentage) / 100) * Math.PI * 2)}%)`,
                                  backgroundColor: item.color,
                                }}
                              />
                            )
                          })}
                        </div>
                      </div>
                      <div className="mt-4 grid grid-cols-3 gap-2">
                        {difficultyDistribution.map((item) => (
                          <div key={item.difficulty} className="flex items-center space-x-2">
                            <div className="h-4 w-4 border-2 border-black" style={{ backgroundColor: item.color }} />
                            <span className="font-minecraft text-xs">
                              {item.difficulty}: {item.percentage}%
                            </span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>

                <PixelTransition className="delay-100">
                  <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                      <div className="flex items-center justify-between">
                        <CardTitle className="font-minecraft text-white">Melhores Jogadores</CardTitle>
                        <Trophy className="h-5 w-5 text-white" />
                      </div>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="space-y-4">
                        {topPerformers.map((player, index) => (
                          <PixelTransition key={player.name} className={`delay-${index * 100}`}>
                            <div className="flex items-center justify-between rounded-md border-2 border-black bg-[#E7E7E7] p-2">
                              <div className="flex items-center space-x-2">
                                <div className="flex h-8 w-8 items-center justify-center rounded-md border-2 border-black bg-[#333333] font-minecraft text-white">
                                  {index + 1}
                                </div>
                                <div>
                                  <p className="font-minecraft text-sm font-medium">{player.name}</p>
                                  <p className="font-minecraft text-xs text-muted-foreground">
                                    {player.quizzes} quizzes
                                  </p>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="font-minecraft text-sm font-bold">{player.score} pts</p>
                                <p className="font-minecraft text-xs text-muted-foreground">
                                  {player.avgTime}s/pergunta
                                </p>
                              </div>
                            </div>
                          </PixelTransition>
                        ))}
                      </div>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>
              </div>
            </TabsContent>

            {/* Desempenho */}
            <TabsContent value="performance" className="space-y-4">
              <PixelTransition>
                <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                  <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                    <div className="flex items-center justify-between">
                      <CardTitle className="font-minecraft text-white">Desempenho por Quiz</CardTitle>
                      <BarChart3 className="h-5 w-5 text-white" />
                    </div>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-6">
                      {quizPerformance.map((quiz, index) => {
                        const scoreBarWidth = `${quiz.avgScore * 10}%`
                        const completionBarWidth = `${quiz.completionRate}%`

                        return (
                          <PixelTransition key={quiz.name} className={`delay-${index * 100}`}>
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <p className="font-minecraft text-sm font-medium">{quiz.name}</p>
                                <p className="font-minecraft text-xs text-muted-foreground">
                                  {quiz.participants} participantes
                                </p>
                              </div>

                              <div className="space-y-1">
                                <div className="flex items-center justify-between">
                                  <p className="font-minecraft text-xs">
                                    Pontuação Média: {quiz.avgScore.toFixed(1)}/10
                                  </p>
                                </div>
                                <div className="h-4 w-full rounded-sm border-2 border-black bg-[#333333]">
                                  <div className="h-full rounded-sm bg-[#EA1D2C]" style={{ width: scoreBarWidth }} />
                                </div>
                              </div>

                              <div className="space-y-1">
                                <div className="flex items-center justify-between">
                                  <p className="font-minecraft text-xs">Taxa de Conclusão: {quiz.completionRate}%</p>
                                </div>
                                <div className="h-4 w-full rounded-sm border-2 border-black bg-[#333333]">
                                  <div
                                    className="h-full rounded-sm bg-[#4CAF50]"
                                    style={{ width: completionBarWidth }}
                                  />
                                </div>
                              </div>
                            </div>
                          </PixelTransition>
                        )
                      })}
                    </div>
                  </CardContent>
                </PixelCard>
              </PixelTransition>

              <div className="grid gap-4 md:grid-cols-2">
                <PixelTransition>
                  <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                      <CardTitle className="font-minecraft text-white">Distribuição de Pontuações</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="h-[200px] w-full">
                        <div className="flex h-full items-end justify-around">
                          {[
                            { range: "0-2", count: 5, color: "#F44336" },
                            { range: "3-4", count: 15, color: "#FF9800" },
                            { range: "5-6", count: 35, color: "#FFC107" },
                            { range: "7-8", count: 30, color: "#8BC34A" },
                            { range: "9-10", count: 15, color: "#4CAF50" },
                          ].map((item) => {
                            const height = `${(item.count / 35) * 100}%`

                            return (
                              <div key={item.range} className="flex w-1/6 flex-col items-center">
                                <div
                                  className="w-full border-2 border-black"
                                  style={{
                                    height,
                                    backgroundColor: item.color,
                                    imageRendering: "pixelated",
                                  }}
                                />
                                <div className="mt-2 font-minecraft text-xs">{item.range}</div>
                              </div>
                            )
                          })}
                        </div>
                      </div>
                      <div className="mt-4 text-center font-minecraft text-sm">Pontuação (escala 0-10)</div>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>

                <PixelTransition className="delay-100">
                  <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                      <CardTitle className="font-minecraft text-white">Comparação de Desempenho</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="space-y-4">
                        <div className="grid grid-cols-3 gap-2 text-center">
                          <div className="rounded-md border-2 border-black bg-[#E7E7E7] p-2">
                            <p className="font-minecraft text-xs text-muted-foreground">Média Geral</p>
                            <p className="font-minecraft text-lg font-bold">{userStats.averageScore.toFixed(1)}</p>
                          </div>
                          <div className="rounded-md border-2 border-black bg-[#E7E7E7] p-2">
                            <p className="font-minecraft text-xs text-muted-foreground">Melhor Quiz</p>
                            <p className="font-minecraft text-lg font-bold">
                              {Math.max(...quizPerformance.map((q) => q.avgScore)).toFixed(1)}
                            </p>
                          </div>
                          <div className="rounded-md border-2 border-black bg-[#E7E7E7] p-2">
                            <p className="font-minecraft text-xs text-muted-foreground">Pior Quiz</p>
                            <p className="font-minecraft text-lg font-bold">
                              {Math.min(...quizPerformance.map((q) => q.avgScore)).toFixed(1)}
                            </p>
                          </div>
                        </div>

                        <div className="rounded-md border-2 border-black bg-[#E7E7E7] p-4">
                          <p className="mb-2 font-minecraft text-sm font-medium">
                            Distribuição de Acertos por Pergunta
                          </p>
                          <div className="grid grid-cols-5 gap-1">
                            {Array.from({ length: 20 }).map((_, i) => {
                              const randomPercentage = 30 + Math.floor(Math.random() * 60)
                              const height = `${randomPercentage}%`
                              const color =
                                randomPercentage > 70 ? "#4CAF50" : randomPercentage > 50 ? "#FFC107" : "#F44336"

                              return (
                                <div key={i} className="flex flex-col items-center">
                                  <div className="h-[80px] w-full">
                                    <div
                                      className="w-full border-2 border-black"
                                      style={{
                                        height,
                                        backgroundColor: color,
                                        marginTop: `calc(100% - ${height})`,
                                        imageRendering: "pixelated",
                                      }}
                                    />
                                  </div>
                                  <div className="mt-1 font-minecraft text-[8px]">P{i + 1}</div>
                                </div>
                              )
                            })}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>
              </div>
            </TabsContent>

            {/* Tempo */}
            <TabsContent value="time" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <PixelTransition>
                  <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                      <div className="flex items-center justify-between">
                        <CardTitle className="font-minecraft text-white">Distribuição de Tempo</CardTitle>
                        <Clock className="h-5 w-5 text-white" />
                      </div>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="flex h-[200px] items-center justify-center">
                        <div className="relative h-[180px] w-[180px] rounded-full border-4 border-black bg-[#333333]">
                          {timeDistribution.map((item, index) => {
                            const previousPercentages = timeDistribution
                              .slice(0, index)
                              .reduce((sum, curr) => sum + curr.percentage, 0)

                            return (
                              <div
                                key={item.range}
                                className="absolute left-1/2 top-1/2 origin-center -translate-x-1/2 -translate-y-1/2"
                                style={{
                                  width: "180px",
                                  height: "180px",
                                  clipPath: `polygon(0 0, 50% 50%, ${50 + 50 * Math.cos((previousPercentages / 100) * Math.PI * 2)}% ${50 + 50 * Math.sin((previousPercentages / 100) * Math.PI * 2)}%, ${50 + 50 * Math.cos(((previousPercentages + item.percentage) / 100) * Math.PI * 2)}% ${50 + 50 * Math.sin(((previousPercentages + item.percentage) / 100) * Math.PI * 2)}%)`,
                                  backgroundColor: item.color,
                                }}
                              />
                            )
                          })}
                        </div>
                      </div>
                      <div className="mt-4 grid grid-cols-4 gap-2">
                        {timeDistribution.map((item) => (
                          <div key={item.range} className="flex items-center space-x-2">
                            <div className="h-4 w-4 border-2 border-black" style={{ backgroundColor: item.color }} />
                            <span className="font-minecraft text-xs">
                              {item.range}: {item.percentage}%
                            </span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>

                <PixelTransition className="delay-100">
                  <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                      <CardTitle className="font-minecraft text-white">Tempo Médio por Quiz</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="space-y-4">
                        {quizPerformance.map((quiz, index) => {
                          // Tempo simulado para cada quiz
                          const avgTime = 15 + Math.floor(Math.random() * 20)
                          const barWidth = `${(avgTime / 45) * 100}%`
                          const barColor = avgTime < 20 ? "#4CAF50" : avgTime < 30 ? "#FFC107" : "#F44336"

                          return (
                            <div key={quiz.name} className="space-y-2">
                              <div className="flex items-center justify-between">
                                <p className="font-minecraft text-sm">{quiz.name}</p>
                                <p className="font-minecraft text-sm font-bold">{avgTime}s</p>
                              </div>
                              <div className="h-4 w-full rounded-sm border-2 border-black bg-[#333333]">
                                <div
                                  className="h-full rounded-sm"
                                  style={{
                                    width: barWidth,
                                    backgroundColor: barColor,
                                  }}
                                />
                              </div>
                            </div>
                          )
                        })}
                      </div>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>
              </div>

              <PixelTransition>
                <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                  <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                    <CardTitle className="font-minecraft text-white">Análise de Tempo por Pergunta</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="overflow-x-auto">
                      <div className="min-w-[600px]">
                        <div className="grid h-[200px] grid-cols-10 gap-2">
                          {Array.from({ length: 10 }).map((_, i) => {
                            const heights = [
                              Math.floor(Math.random() * 60) + 20,
                              Math.floor(Math.random() * 60) + 20,
                              Math.floor(Math.random() * 60) + 20,
                            ]

                            return (
                              <div key={i} className="flex flex-col items-center">
                                <div className="flex h-full w-full flex-col-reverse">
                                  <div className="flex w-full justify-center space-x-1">
                                    <div
                                      className="w-2 border-2 border-black bg-[#2196F3]"
                                      style={{ height: `${heights[0]}%` }}
                                    />
                                    <div
                                      className="w-2 border-2 border-black bg-[#FFC107]"
                                      style={{ height: `${heights[1]}%` }}
                                    />
                                    <div
                                      className="w-2 border-2 border-black bg-[#F44336]"
                                      style={{ height: `${heights[2]}%` }}
                                    />
                                  </div>
                                </div>
                                <div className="mt-2 font-minecraft text-xs">P{i + 1}</div>
                              </div>
                            )
                          })}
                        </div>
                        <div className="mt-4 flex justify-center space-x-4">
                          <div className="flex items-center space-x-2">
                            <div className="h-4 w-4 border-2 border-black bg-[#2196F3]" />
                            <span className="font-minecraft text-xs">Fácil</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <div className="h-4 w-4 border-2 border-black bg-[#FFC107]" />
                            <span className="font-minecraft text-xs">Médio</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <div className="h-4 w-4 border-2 border-black bg-[#F44336]" />
                            <span className="font-minecraft text-xs">Difícil</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </PixelCard>
              </PixelTransition>
            </TabsContent>

            {/* Tendências */}
            <TabsContent value="trends" className="space-y-4">
              <PixelTransition>
                <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                  <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                    <div className="flex items-center justify-between">
                      <CardTitle className="font-minecraft text-white">Tendências Mensais</CardTitle>
                      <LineChart className="h-5 w-5 text-white" />
                    </div>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="h-[250px] w-full">
                      <div className="relative h-full w-full border-b-2 border-l-2 border-black">
                        {/* Eixo Y */}
                        <div className="absolute -left-8 top-0 h-full">
                          <div className="flex h-full flex-col justify-between">
                            <span className="font-minecraft text-xs">600</span>
                            <span className="font-minecraft text-xs">400</span>
                            <span className="font-minecraft text-xs">200</span>
                            <span className="font-minecraft text-xs">0</span>
                          </div>
                        </div>

                        {/* Linhas de grade */}
                        <div className="absolute left-0 top-0 h-1/3 w-full border-b border-dashed border-gray-400" />
                        <div className="absolute left-0 top-1/3 h-1/3 w-full border-b border-dashed border-gray-400" />
                        <div className="absolute left-0 top-2/3 h-1/3 w-full border-b border-dashed border-gray-400" />

                        {/* Gráfico de linha para quizzes */}
                        <svg className="absolute inset-0 h-full w-full" preserveAspectRatio="none">
                          <polyline
                            points={monthlyData
                              .map((data, i) => {
                                const x = (i / (monthlyData.length - 1)) * 100
                                const y = 100 - (data.quizzes / 650) * 100
                                return `${x},${y}`
                              })
                              .join(" ")}
                            fill="none"
                            stroke="#EA1D2C"
                            strokeWidth="3"
                            vectorEffect="non-scaling-stroke"
                          />
                        </svg>

                        {/* Gráfico de linha para usuários */}
                        <svg className="absolute inset-0 h-full w-full" preserveAspectRatio="none">
                          <polyline
                            points={monthlyData
                              .map((data, i) => {
                                const x = (i / (monthlyData.length - 1)) * 100
                                const y = 100 - (data.users / 250) * 100
                                return `${x},${y}`
                              })
                              .join(" ")}
                            fill="none"
                            stroke="#2196F3"
                            strokeWidth="3"
                            vectorEffect="non-scaling-stroke"
                          />
                        </svg>

                        {/* Pontos de dados para quizzes */}
                        {monthlyData.map((data, i) => {
                          const left = `${(i / (monthlyData.length - 1)) * 100}%`
                          const top = `${100 - (data.quizzes / 650) * 100}%`

                          return (
                            <div
                              key={`quiz-${data.month}`}
                              className="absolute h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-black bg-[#EA1D2C]"
                              style={{ left, top }}
                            />
                          )
                        })}

                        {/* Pontos de dados para usuários */}
                        {monthlyData.map((data, i) => {
                          const left = `${(i / (monthlyData.length - 1)) * 100}%`
                          const top = `${100 - (data.users / 250) * 100}%`

                          return (
                            <div
                              key={`user-${data.month}`}
                              className="absolute h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-black bg-[#2196F3]"
                              style={{ left, top }}
                            />
                          )
                        })}
                      </div>
                    </div>

                    {/* Eixo X */}
                    <div className="mt-2 flex justify-between">
                      {monthlyData.map((data) => (
                        <span key={data.month} className="font-minecraft text-xs">
                          {data.month}
                        </span>
                      ))}
                    </div>

                    {/* Legenda */}
                    <div className="mt-4 flex justify-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <div className="h-4 w-4 border-2 border-black bg-[#EA1D2C]" />
                        <span className="font-minecraft text-xs">Quizzes</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="h-4 w-4 border-2 border-black bg-[#2196F3]" />
                        <span className="font-minecraft text-xs">Usuários</span>
                      </div>
                    </div>
                  </CardContent>
                </PixelCard>
              </PixelTransition>

              <div className="grid gap-4 md:grid-cols-2">
                <PixelTransition>
                  <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                      <CardTitle className="font-minecraft text-white">Evolução da Pontuação Média</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="h-[200px] w-full">
                        <div className="relative h-full w-full border-b-2 border-l-2 border-black">
                          {/* Eixo Y */}
                          <div className="absolute -left-8 top-0 h-full">
                            <div className="flex h-full flex-col justify-between">
                              <span className="font-minecraft text-xs">10</span>
                              <span className="font-minecraft text-xs">7.5</span>
                              <span className="font-minecraft text-xs">5</span>
                              <span className="font-minecraft text-xs">2.5</span>
                              <span className="font-minecraft text-xs">0</span>
                            </div>
                          </div>

                          {/* Linhas de grade */}
                          <div className="absolute left-0 top-1/4 h-1/4 w-full border-b border-dashed border-gray-400" />
                          <div className="absolute left-0 top-2/4 h-1/4 w-full border-b border-dashed border-gray-400" />
                          <div className="absolute left-0 top-3/4 h-1/4 w-full border-b border-dashed border-gray-400" />

                          {/* Gráfico de linha para pontuação média */}
                          <svg className="absolute inset-0 h-full w-full" preserveAspectRatio="none">
                            <polyline
                              points={monthlyData
                                .map((data, i) => {
                                  const x = (i / (monthlyData.length - 1)) * 100
                                  const y = 100 - (data.avgScore / 10) * 100
                                  return `${x},${y}`
                                })
                                .join(" ")}
                              fill="none"
                              stroke="#4CAF50"
                              strokeWidth="3"
                              vectorEffect="non-scaling-stroke"
                            />
                          </svg>

                          {/* Pontos de dados */}
                          {monthlyData.map((data, i) => {
                            const left = `${(i / (monthlyData.length - 1)) * 100}%`
                            const top = `${100 - (data.avgScore / 10) * 100}%`

                            return (
                              <div
                                key={data.month}
                                className="absolute h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-black bg-[#4CAF50]"
                                style={{ left, top }}
                              >
                                <div className="absolute left-1/2 top-0 -translate-x-1/2 -translate-y-6 whitespace-nowrap rounded-md border-2 border-black bg-[#333333] px-1 py-0.5 font-minecraft text-xs text-white">
                                  {data.avgScore.toFixed(1)}
                                </div>
                              </div>
                            )
                          })}
                        </div>
                      </div>

                      {/* Eixo X */}
                      <div className="mt-2 flex justify-between">
                        {monthlyData.map((data) => (
                          <span key={data.month} className="font-minecraft text-xs">
                            {data.month}
                          </span>
                        ))}
                      </div>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>

                <PixelTransition className="delay-100">
                  <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                      <CardTitle className="font-minecraft text-white">Atividade por Dia da Semana</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="h-[200px] w-full">
                        <div className="flex h-full items-end justify-around">
                          {[
                            { day: "Dom", count: 45, color: "#E91E63" },
                            { day: "Seg", count: 65, color: "#9C27B0" },
                            { day: "Ter", count: 80, color: "#673AB7" },
                            { day: "Qua", count: 95, color: "#3F51B5" },
                            { day: "Qui", count: 85, color: "#2196F3" },
                            { day: "Sex", count: 75, color: "#03A9F4" },
                            { day: "Sáb", count: 55, color: "#00BCD4" },
                          ].map((item) => {
                            const height = `${(item.count / 100) * 100}%`

                            return (
                              <div key={item.day} className="flex w-1/8 flex-col items-center">
                                <div
                                  className="w-full border-2 border-black"
                                  style={{
                                    height,
                                    backgroundColor: item.color,
                                    imageRendering: "pixelated",
                                  }}
                                />
                                <div className="mt-2 font-minecraft text-xs">{item.day}</div>
                              </div>
                            )
                          })}
                        </div>
                      </div>
                      <div className="mt-4 text-center font-minecraft text-sm">Dias da Semana</div>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>
              </div>
            </TabsContent>
          </Tabs>
        </PageTransition>
      </div>
    </div>
  )
}
