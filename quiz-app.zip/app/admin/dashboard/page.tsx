"use client"

import { useState, useEffect } from "react"
import { BarChart3, Users, FileText, Settings, LogOut, Plus, Clock, Trophy, ListChecks, LineChart } from "lucide-react"
import { CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useRouter } from "next/navigation"
import { PageTransition, PixelButton, PixelCard, PixelTransition, LinkWrapper } from "@/components/pixel-transition"

// Dados simulados
const quizzes = [
  { id: 1, title: "Conhecimentos Gerais", participants: 145, avgScore: 7.2, timeLimit: 60 },
  { id: 2, title: "História do Brasil", participants: 89, avgScore: 6.5, timeLimit: 90 },
  { id: 3, title: "Matemática Básica", participants: 120, avgScore: 8.1, timeLimit: 45 },
  { id: 4, title: "Geografia Mundial", participants: 75, avgScore: 7.8, timeLimit: 75 },
]

const recentUsers = [
  { id: 1, name: "João Silva", email: "joao@example.com", date: "2023-05-01" },
  { id: 2, name: "Maria Oliveira", email: "maria@example.com", date: "2023-05-01" },
  { id: 3, name: "Pedro Santos", email: "pedro@example.com", date: "2023-05-02" },
  { id: 4, name: "Ana Costa", email: "ana@example.com", date: "2023-05-03" },
]

const rankingData = [
  { id: 1, name: "Carlos Oliveira", score: 950, quizzes: 15, avatar: "🧙‍♂️" },
  { id: 2, name: "Mariana Silva", score: 820, quizzes: 12, avatar: "👸" },
  { id: 3, name: "Rafael Souza", score: 780, quizzes: 14, avatar: "🤖" },
  { id: 4, name: "Juliana Costa", score: 750, quizzes: 10, avatar: "🦊" },
  { id: 5, name: "Fernando Lima", score: 720, quizzes: 11, avatar: "🐱" },
  { id: 6, name: "Camila Santos", score: 690, quizzes: 9, avatar: "🦄" },
  { id: 7, name: "Bruno Alves", score: 650, quizzes: 8, avatar: "🐺" },
  { id: 8, name: "Larissa Pereira", score: 620, quizzes: 7, avatar: "🦁" },
]

export default function AdminDashboard() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("overview")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleLogout = () => {
    router.push("/login")
  }

  if (!mounted) return null

  return (
    <div className="flex min-h-screen flex-col bg-[#333333] bg-[url('/placeholder.svg?height=600&width=600')] bg-repeat scanline">
      <div className="border-b-4 border-black bg-[#EA1D2C]">
        <div className="container mx-auto flex h-16 items-center px-4">
          <div className="flex items-center space-x-4">
            <span className="font-minecraft text-2xl font-bold text-white drop-shadow-[2px_2px_0px_#000]">
              QuizCraft
            </span>
            <span className="rounded-md border-2 border-black bg-[#333333] px-2 py-1 font-minecraft text-xs text-white pixel-glow">
              ADMIN
            </span>
          </div>
          <div className="ml-auto flex items-center space-x-4">
            <PixelButton
              onClick={handleLogout}
              className="border-2 border-black bg-[#333333] font-minecraft text-white"
            >
              <LogOut className="mr-2 h-4 w-4" />
              Sair
            </PixelButton>
          </div>
        </div>
      </div>
      <div className="container mx-auto flex-1 space-y-4 p-8 pt-6">
        <PageTransition>
          <div className="flex items-center justify-between space-y-2">
            <h1 className="font-minecraft text-3xl font-bold text-white drop-shadow-[2px_2px_0px_#000] text-appear">
              Painel Administrativo
            </h1>
            <div className="flex items-center space-x-2">
              <LinkWrapper href="/admin/quizzes/new">
                <PixelButton className="border-b-4 border-r-4 border-black bg-[#EA1D2C] font-minecraft text-white">
                  <Plus className="mr-2 h-4 w-4" />
                  Criar Novo Quiz
                </PixelButton>
              </LinkWrapper>
            </div>
          </div>
          <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList className="border-2 border-black bg-[#C6C6C6] p-1">
              <TabsTrigger
                value="overview"
                className="font-minecraft data-[state=active]:border-b-4 data-[state=active]:border-r-4 data-[state=active]:border-black data-[state=active]:bg-[#EA1D2C] data-[state=active]:text-white"
              >
                Visão Geral
              </TabsTrigger>
              <TabsTrigger
                value="quizzes"
                className="font-minecraft data-[state=active]:border-b-4 data-[state=active]:border-r-4 data-[state=active]:border-black data-[state=active]:bg-[#EA1D2C] data-[state=active]:text-white"
              >
                Quizzes
              </TabsTrigger>
              <TabsTrigger
                value="ranking"
                className="font-minecraft data-[state=active]:border-b-4 data-[state=active]:border-r-4 data-[state=active]:border-black data-[state=active]:bg-[#EA1D2C] data-[state=active]:text-white"
              >
                Ranking
              </TabsTrigger>
              <TabsTrigger
                value="time"
                className="font-minecraft data-[state=active]:border-b-4 data-[state=active]:border-r-4 data-[state=active]:border-black data-[state=active]:bg-[#EA1D2C] data-[state=active]:text-white"
              >
                Tempo
              </TabsTrigger>
              <TabsTrigger
                value="users"
                className="font-minecraft data-[state=active]:border-b-4 data-[state=active]:border-r-4 data-[state=active]:border-black data-[state=active]:bg-[#EA1D2C] data-[state=active]:text-white"
              >
                Usuários
              </TabsTrigger>
            </TabsList>
            <TabsContent value="overview" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <PixelTransition>
                  <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C] pb-2">
                      <div className="flex flex-row items-center justify-between space-y-0">
                        <CardTitle className="font-minecraft text-sm text-white">Total de Quizzes</CardTitle>
                        <FileText className="h-4 w-4 text-white" />
                      </div>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <div className="font-minecraft text-2xl font-bold">{quizzes.length}</div>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>

                <PixelTransition className="delay-100">
                  <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C] pb-2">
                      <div className="flex flex-row items-center justify-between space-y-0">
                        <CardTitle className="font-minecraft text-sm text-white">Usuários</CardTitle>
                        <Users className="h-4 w-4 text-white" />
                      </div>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <div className="font-minecraft text-2xl font-bold">256</div>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>

                <PixelTransition className="delay-200">
                  <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C] pb-2">
                      <div className="flex flex-row items-center justify-between space-y-0">
                        <CardTitle className="font-minecraft text-sm text-white">Participações</CardTitle>
                        <BarChart3 className="h-4 w-4 text-white" />
                      </div>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <div className="font-minecraft text-2xl font-bold">429</div>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>

                <PixelTransition className="delay-300">
                  <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C] pb-2">
                      <div className="flex flex-row items-center justify-between space-y-0">
                        <CardTitle className="font-minecraft text-sm text-white">Média</CardTitle>
                        <Settings className="h-4 w-4 text-white" />
                      </div>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <div className="font-minecraft text-2xl font-bold">7.4</div>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>
              </div>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
                <PixelTransition className="col-span-4">
                  <PixelCard className="col-span-4 border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                      <CardTitle className="font-minecraft text-white">Quizzes Populares</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="space-y-4">
                        {quizzes.map((quiz, index) => (
                          <PixelTransition key={quiz.id} className={`delay-${index * 100}`}>
                            <div className="flex items-center justify-between rounded-md border-2 border-black bg-[#E7E7E7] p-2">
                              <div className="space-y-1">
                                <p className="font-minecraft text-sm font-medium leading-none">{quiz.title}</p>
                                <p className="font-minecraft text-sm text-muted-foreground">
                                  {quiz.participants} participantes
                                </p>
                              </div>
                              <div className="flex items-center space-x-2">
                                <span className="font-minecraft text-sm font-medium">
                                  Média: {quiz.avgScore.toFixed(1)}
                                </span>
                              </div>
                            </div>
                          </PixelTransition>
                        ))}
                      </div>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>

                <PixelTransition className="col-span-3">
                  <PixelCard className="col-span-3 border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                    <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                      <CardTitle className="font-minecraft text-white">Usuários Recentes</CardTitle>
                      <CardDescription className="font-minecraft text-white opacity-90">
                        {recentUsers.length} usuários registrados recentemente
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="space-y-4">
                        {recentUsers.map((user, index) => (
                          <PixelTransition key={user.id} className={`delay-${index * 100}`}>
                            <div className="flex items-center justify-between rounded-md border-2 border-black bg-[#E7E7E7] p-2">
                              <div className="space-y-1">
                                <p className="font-minecraft text-sm font-medium leading-none">{user.name}</p>
                                <p className="font-minecraft text-sm text-muted-foreground">{user.email}</p>
                              </div>
                              <div className="font-minecraft text-sm text-muted-foreground">
                                {new Date(user.date).toLocaleDateString()}
                              </div>
                            </div>
                          </PixelTransition>
                        ))}
                      </div>
                    </CardContent>
                  </PixelCard>
                </PixelTransition>
              </div>

              <div className="flex justify-end">
                <LinkWrapper href="/admin/statistics">
                  <PixelButton className="border-b-4 border-r-4 border-black bg-[#333333] font-minecraft text-white">
                    <LineChart className="mr-2 h-4 w-4" />
                    Ver Estatísticas Detalhadas
                  </PixelButton>
                </LinkWrapper>
              </div>
            </TabsContent>

            <TabsContent value="quizzes" className="space-y-4">
              <PixelTransition>
                <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                  <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                    <CardTitle className="font-minecraft text-white">Gerenciar Quizzes</CardTitle>
                    <CardDescription className="font-minecraft text-white opacity-90">
                      Visualize, edite e crie novos quizzes para sua plataforma.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="rounded-md border-4 border-black">
                        <div className="grid grid-cols-5 gap-4 bg-[#EA1D2C] p-4 font-minecraft font-medium text-white">
                          <div>Título</div>
                          <div>Participantes</div>
                          <div>Pontuação Média</div>
                          <div>Tempo (seg)</div>
                          <div className="text-right">Ações</div>
                        </div>
                        {quizzes.map((quiz, index) => (
                          <PixelTransition key={quiz.id} className={`delay-${index * 100}`}>
                            <div
                              className={`grid grid-cols-5 gap-4 border-t-2 border-black p-4 ${
                                index % 2 === 0 ? "bg-[#E7E7E7]" : "bg-[#D0D0D0]"
                              }`}
                            >
                              <div className="font-minecraft">{quiz.title}</div>
                              <div className="font-minecraft">{quiz.participants}</div>
                              <div className="font-minecraft">{quiz.avgScore.toFixed(1)}</div>
                              <div className="font-minecraft">{quiz.timeLimit}</div>
                              <div className="flex justify-end space-x-2">
                                <LinkWrapper href={`/admin/quizzes/${quiz.id}/edit`}>
                                  <PixelButton
                                    size="sm"
                                    className="border-2 border-black bg-[#C6C6C6] font-minecraft text-black"
                                  >
                                    Editar
                                  </PixelButton>
                                </LinkWrapper>
                                <LinkWrapper href={`/admin/quizzes/${quiz.id}/questions`}>
                                  <PixelButton
                                    size="sm"
                                    className="border-2 border-black bg-[#333333] font-minecraft text-white"
                                  >
                                    <ListChecks className="mr-1 h-3 w-3" />
                                    Perguntas
                                  </PixelButton>
                                </LinkWrapper>
                                <PixelButton
                                  size="sm"
                                  className="border-2 border-black bg-[#EA1D2C] font-minecraft text-white"
                                >
                                  Excluir
                                </PixelButton>
                              </div>
                            </div>
                          </PixelTransition>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </PixelCard>
              </PixelTransition>
            </TabsContent>

            <TabsContent value="ranking" className="space-y-4">
              <PixelTransition>
                <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                  <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="font-minecraft text-white">Ranking de Jogadores</CardTitle>
                        <CardDescription className="font-minecraft text-white opacity-90">
                          Visualize e gerencie o ranking dos jogadores na plataforma.
                        </CardDescription>
                      </div>
                      <Trophy className="h-6 w-6 text-white" />
                    </div>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="rounded-md border-4 border-black">
                        <div className="grid grid-cols-5 gap-4 bg-[#EA1D2C] p-4 font-minecraft font-medium text-white">
                          <div>Posição</div>
                          <div>Jogador</div>
                          <div>Pontuação</div>
                          <div>Quizzes</div>
                          <div className="text-right">Ações</div>
                        </div>
                        {rankingData.map((player, index) => (
                          <PixelTransition key={player.id} className={`delay-${index * 100}`}>
                            <div
                              className={`grid grid-cols-5 gap-4 border-t-2 border-black p-4 ${
                                index % 2 === 0 ? "bg-[#E7E7E7]" : "bg-[#D0D0D0]"
                              } ${index < 3 ? "pixel-glow" : ""}`}
                            >
                              <div className="flex items-center font-minecraft">
                                {index === 0 && "🥇 "}
                                {index === 1 && "🥈 "}
                                {index === 2 && "🥉 "}
                                {index + 1}
                              </div>
                              <div className="flex items-center gap-2 font-minecraft">
                                <span className="flex h-8 w-8 items-center justify-center rounded-md border-2 border-black bg-[#333333] text-lg">
                                  {player.avatar}
                                </span>
                                {player.name}
                              </div>
                              <div className="font-minecraft">{player.score}</div>
                              <div className="font-minecraft">{player.quizzes}</div>
                              <div className="flex justify-end space-x-2">
                                <PixelButton
                                  size="sm"
                                  className="border-2 border-black bg-[#C6C6C6] font-minecraft text-black"
                                >
                                  Detalhes
                                </PixelButton>
                                <PixelButton
                                  size="sm"
                                  className="border-2 border-black bg-[#EA1D2C] font-minecraft text-white"
                                >
                                  Resetar
                                </PixelButton>
                              </div>
                            </div>
                          </PixelTransition>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </PixelCard>
              </PixelTransition>
            </TabsContent>

            <TabsContent value="time" className="space-y-4">
              <PixelTransition>
                <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                  <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="font-minecraft text-white">Gerenciar Tempo</CardTitle>
                        <CardDescription className="font-minecraft text-white opacity-90">
                          Configure o tempo de resposta para cada quiz.
                        </CardDescription>
                      </div>
                      <Clock className="h-6 w-6 text-white" />
                    </div>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="rounded-md border-4 border-black">
                        <div className="grid grid-cols-4 gap-4 bg-[#EA1D2C] p-4 font-minecraft font-medium text-white">
                          <div>Quiz</div>
                          <div>Tempo Atual (seg)</div>
                          <div>Tempo por Pergunta</div>
                          <div className="text-right">Ações</div>
                        </div>
                        {quizzes.map((quiz, index) => (
                          <PixelTransition key={quiz.id} className={`delay-${index * 100}`}>
                            <div
                              className={`grid grid-cols-4 gap-4 border-t-2 border-black p-4 ${
                                index % 2 === 0 ? "bg-[#E7E7E7]" : "bg-[#D0D0D0]"
                              }`}
                            >
                              <div className="font-minecraft">{quiz.title}</div>
                              <div className="font-minecraft">{quiz.timeLimit} segundos</div>
                              <div className="font-minecraft">{Math.round(quiz.timeLimit / 5)} segundos/pergunta</div>
                              <div className="flex justify-end space-x-2">
                                <PixelButton
                                  size="sm"
                                  className="border-2 border-black bg-[#C6C6C6] font-minecraft text-black"
                                >
                                  Editar Tempo
                                </PixelButton>
                              </div>
                            </div>
                          </PixelTransition>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </PixelCard>
              </PixelTransition>
            </TabsContent>

            <TabsContent value="users" className="space-y-4">
              <PixelTransition>
                <PixelCard className="border-4 border-black bg-[#C6C6C6] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]">
                  <CardHeader className="border-b-4 border-black bg-[#EA1D2C]">
                    <CardTitle className="font-minecraft text-white">Gerenciar Usuários</CardTitle>
                    <CardDescription className="font-minecraft text-white opacity-90">
                      Visualize e gerencie os usuários registrados na plataforma.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="rounded-md border-4 border-black">
                        <div className="grid grid-cols-4 gap-4 bg-[#EA1D2C] p-4 font-minecraft font-medium text-white">
                          <div>Nome</div>
                          <div>Email</div>
                          <div>Data de Registro</div>
                          <div className="text-right">Ações</div>
                        </div>
                        {recentUsers.map((user, index) => (
                          <PixelTransition key={user.id} className={`delay-${index * 100}`}>
                            <div
                              className={`grid grid-cols-4 gap-4 border-t-2 border-black p-4 ${
                                index % 2 === 0 ? "bg-[#E7E7E7]" : "bg-[#D0D0D0]"
                              }`}
                            >
                              <div className="font-minecraft">{user.name}</div>
                              <div className="font-minecraft">{user.email}</div>
                              <div className="font-minecraft">{new Date(user.date).toLocaleDateString()}</div>
                              <div className="flex justify-end space-x-2">
                                <PixelButton
                                  size="sm"
                                  className="border-2 border-black bg-[#C6C6C6] font-minecraft text-black"
                                >
                                  Editar
                                </PixelButton>
                                <PixelButton
                                  size="sm"
                                  className="border-2 border-black bg-[#EA1D2C] font-minecraft text-white"
                                >
                                  Excluir
                                </PixelButton>
                              </div>
                            </div>
                          </PixelTransition>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </PixelCard>
              </PixelTransition>
            </TabsContent>
          </Tabs>
        </PageTransition>
      </div>
    </div>
  )
}
